export const actionTypes = {
    fetch_books: "fetch_books",
    fetch_book_id: "fetch_book_id",
    remove_book_id: "remove_book_id"
}