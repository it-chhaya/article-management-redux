export const BASE_URL = 'https://jsonplaceholder.typicode.com/'
export const BOOK_BASE_URL = 'http://localhost:8081/'
// https://bookapi.istad.com/